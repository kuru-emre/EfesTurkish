<div class="eltdf-comment-input-title">
	<label><?php esc_html_e( 'Title of your Review', 'laurent-core' ) ?></label>
	<input id="title" name="eltdf_comment_title" class="eltdf-input-field" type="text" />
</div>