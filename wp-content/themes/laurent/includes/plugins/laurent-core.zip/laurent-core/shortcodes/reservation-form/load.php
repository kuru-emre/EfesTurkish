<?php

include_once LAURENT_CORE_SHORTCODES_PATH.'/reservation-form/functions.php';
include_once LAURENT_CORE_SHORTCODES_PATH.'/reservation-form/reservation-form.php';