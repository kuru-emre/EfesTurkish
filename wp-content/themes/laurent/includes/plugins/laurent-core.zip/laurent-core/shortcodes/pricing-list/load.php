<?php

include_once LAURENT_CORE_SHORTCODES_PATH . '/pricing-list/functions.php';
include_once LAURENT_CORE_SHORTCODES_PATH . '/pricing-list/pricing-list.php';