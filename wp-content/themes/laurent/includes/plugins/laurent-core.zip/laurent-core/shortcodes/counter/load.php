<?php

include_once LAURENT_CORE_SHORTCODES_PATH . '/counter/functions.php';
include_once LAURENT_CORE_SHORTCODES_PATH . '/counter/counter.php';