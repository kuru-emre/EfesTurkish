<?php

include_once LAURENT_CORE_SHORTCODES_PATH . '/stacked-images/functions.php';
include_once LAURENT_CORE_SHORTCODES_PATH . '/stacked-images/stacked-images.php';