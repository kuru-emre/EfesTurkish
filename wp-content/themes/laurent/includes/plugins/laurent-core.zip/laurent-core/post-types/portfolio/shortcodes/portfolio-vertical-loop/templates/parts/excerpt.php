<?php $excerpt = get_the_excerpt(); ?>

<p itemprop="description" class="eltdf-pvli-excerpt"><?php echo esc_html($excerpt); ?></p>
