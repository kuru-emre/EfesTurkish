<?php

get_header();

laurent_elated_get_title();

do_action('laurent_elated_action_before_main_content');

laurent_core_get_single_portfolio();

get_footer();